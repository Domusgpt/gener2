﻿# GEN-R-L MiLLz Reality Distortion System

This is an interactive reality-warping website dedicated to GEN-R-L MiLLz, the Breakfast Deity & Reality Architect.

## Features

- Interactive color physics system
- 3D particle fields with connections
- Dimensional portals and rifts
- Dynamic content that responds to chaos levels
- Unlockable cosmic artifacts collection system

## How to Use

1. Open index.html in a modern browser
2. Interact with the following elements:
   - Mouse movement: Creates ripples in the color physics system
   - Mouse click: Creates new color bodies
   - Double-click: Opens dimensional portals
   - SOUND button: Enables ambient audio
   - DIMENSIONS button: Shifts reality by increasing dimensions
   - CHAOS button: Controls the intensity of all effects
   - Type "cereal" to reveal the secret code input
   - Use today's code to unlock cosmic artifacts

## Image Collection

Update the placeholder images in the following folders:
- images/artifacts/legendary/ (3 images)
- images/artifacts/epic/ (7 images)
- images/artifacts/rare/ (15 images)
- images/artifacts/uncommon/ (30 images)
- images/artifacts/common/ (55 images)

## Daily Secret Code

Update the 'todaysSecretCode' variable in the initUnlockableSystem function regularly.
